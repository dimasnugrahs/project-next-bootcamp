import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(req) {
    try {
        //Get name on body
        const { name, password, email, access_token, role } = await req.json();

        //Create user with prisma
        const user = await db.user.create({
            data: {
                name: name,
                password: password,
                email: email,
                access_token : access_token,
                role: role
            },
        });

        //Return category to the client
        return NextResponse.json(user, {status: 201});
    } catch (error) {
        console.log(err);
        //Return error response
        return new NextResponse("Internal server error", {status: 500});
    }
}

export async function GET(req) {
    // try {
    //     //Get all products
    //     const products = await db.product.findMany();

    //     //Return category to client
    //     return NextResponse.json(products, {status: 201});
    // } catch (err) {
    //     console.error(err)
    //     return new NextResponse("Internal server error", {status:  500})
    // }
}